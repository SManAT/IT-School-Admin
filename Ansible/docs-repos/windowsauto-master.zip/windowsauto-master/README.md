# windowsauto
Ansible Playbooks for Windows

Note these are for demo purposes only. Please rework them for your Prod needs. 
